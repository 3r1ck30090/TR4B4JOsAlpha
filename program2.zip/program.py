a = int(input())
b = int(input())
c = int(input())
auxi = a / b
print("%.3f" % (auxi))
auxi = a % b
print(int(auxi))
auxi = a / b - c
print("%.3f" % (auxi))
auxi = a / (b - c)
print("%.3f" % (auxi))