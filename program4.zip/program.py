def valida(num):
    if num > 0:
        return True
    else:
        return False

def corriente(voltaje, resistencia):
    if resistencia <= 0:   
        return -1
    return voltaje / resistencia

def voltaje(corriente, resistencia):
    return corriente * resistencia

def resistencia(corriente, voltaje):
    if corriente <= 0:   
        return -1
    return voltaje / corriente

opcion = int(input())  

if opcion == 1:
    num = float(input())
    print(valida(num))
elif opcion == 2:
    v = float(input())
    r = float(input())
    print(corriente(v, r))
elif opcion == 3:
    i = float(input())
    r = float(input())
    print(voltaje(i, r))
elif opcion == 4:
    i = float(input())
    v = float(input())
    print(resistencia(i, v))
else:
    print("entrada no valida")
