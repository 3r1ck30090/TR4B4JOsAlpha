def eleva_potencia(num, potencia):
    if potencia == 0:
        return 1
    resultado = num

    for _ in range(1, potencia):
        acumulador = 0
        for _ in range(num):
            acumulador += resultado
        resultado = acumulador
    return resultado

def aproximacion_PI(num):
    pi_aprox = 0
    signo = 1
    for k in range(num):
        pi_aprox += signo * (1 / (2 * k + 1))
        signo *= -1
    return 4 * pi_aprox

def date_sim_pikachu():
    while True:
        texto = input()
        if texto == "pikapika":
            print("chu")
        elif texto == "pika!":
            print("pika")
        elif texto == "pikachu":
            print("pikachu!!!")

opcion = int(input())

if opcion == 1:
    num = int(input())
    pot = int(input())
    print(eleva_potencia(num, pot))
elif opcion == 2:
    limite = int(input())
    print(f"{aproximacion_PI(limite):.3f}")
elif opcion == 3:
    date_sim_pikachu()
else:
    print("entrada no valida")
